let dados = []
function criarBase() {
let nome = document.getElementById("nome").value
let rgm = document.getElementById("rgm").value
let falta = document.getElementById("faltas").value

let objeto = {nome:`${nome}` , rgm:`${rgm}` , falta:`${falta}` ,}

dados.push(objeto)

console.log(dados)
}

function criarTabela(){
document.getElementById("corpotabela").innerHTML = ""

dados.forEach(function(index){
    let tabela = document.getElementById("corpotabela")
    let tr = document.createElement('tr') /*linhas da tabela*/

    tr.innerHTML = `
    <tr> 
        <td>${dados[index].nome}</td>
        <td>${dados[index].rgm}</td>
        <td>${dados[index].falta}</td>
    </tr>
    `
    //td é filha de tr
    tabela.appendChild(tr) // criando um filho tr
    
}) 


}